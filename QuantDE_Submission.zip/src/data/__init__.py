# Data loading utilities
