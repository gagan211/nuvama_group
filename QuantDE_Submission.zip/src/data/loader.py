"""
Data Loading Utilities

Handles CSV and Parquet I/O for tick and OHLCV data.
"""

import pandas as pd
from pathlib import Path


def load_tick_data(filepath: str) -> pd.DataFrame:
    """
    Load tick data from CSV file
    Returns:
        DataFrame with columns: timestamp, symbol, price, volume
        timestamp is parsed as datetime and set as index.
    """
    df = pd.read_csv(
        filepath,
        parse_dates=['timestamp'],
        dtype={
            'symbol': 'category', # memory saving param
            'price': 'float64',
            'volume': 'int64'
        }
    )
    df.set_index('timestamp', inplace=True)
    df.sort_index(inplace=True)
    return df


def save_to_parquet(df: pd.DataFrame, filepath: str) -> None:
    """Save DataFrame to Parquet format for efficient storage."""
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(filepath, engine='pyarrow', compression='snappy') #high speed compressions


def load_from_parquet(filepath: str) -> pd.DataFrame:
    """loaded from Parquet."""
    return pd.read_parquet(filepath, engine='pyarrow')
