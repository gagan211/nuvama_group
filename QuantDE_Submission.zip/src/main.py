"""
QuantDE Backtesting Framework - Unified Entry Point
"""

import argparse
import sys
import os
from pathlib import Path

script_dir = Path(__file__).resolve().parent
project_root = script_dir.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from src.data.loader import load_tick_data, save_to_parquet, load_from_parquet
from src.processing.resampler import resample_ohlcv
from src.processing.indicators import add_moving_average, add_volatility, add_bollinger_bands
from src.strategy.mean_reversion import generate_signals
from src.strategy.backtest import run_backtest
from src.risk.controls import apply_position_limits, check_daily_loss
from src.risk.stress_test import apply_price_shock
from src.strategy.pnl import generate_intraday_pnl_curve
from src.utils.plotting import plot_pnl_curve, plot_bollinger_bands


def Market_Data_Processing(input_path, output_dir):
    print("\n[Stage 1] Market Data Processing")
    ticks = load_tick_data(input_path)
    ohlcv = resample_ohlcv(ticks, freq='1min')
    ohlcv = add_moving_average(ohlcv, period=20)
    ohlcv = add_volatility(ohlcv, period=20)
    ohlcv = add_bollinger_bands(ohlcv, period=20, num_std=1.0)
    ohlcv_clean = ohlcv.dropna()
    
    save_to_parquet(ohlcv_clean, os.path.join(output_dir, 'ohlcv_ready.parquet'))
    plot_bollinger_bands(ohlcv_clean, os.path.join(output_dir, 'plots'))
    return ohlcv_clean

def Strategy_Backtest(df, output_dir):
    print("[Stage 2] Strategy Backtest & PnL Tracking")
    df = df.reset_index()
    df = generate_signals(df, price_col='close')
    df = df.set_index(['timestamp', 'symbol'])
    
    results = run_backtest(df, commission=0.0001, price_col='close')
    
    print("\n" + "="*45)
    print("      BACKTEST PERFORMANCE SUMMARY")
    print("="*45)
    for k, v in results.items():
        if k != 'trades':
            print(f"{k.replace('_', ' ').title():<25}: {v}")
    print("="*45)
    
    pnl_intraday = generate_intraday_pnl_curve(df, results['trades'], price_col='close')
    save_to_parquet(pnl_intraday, os.path.join(output_dir, 'intraday_pnl.parquet'))
    save_to_parquet(results['trades'], os.path.join(output_dir, 'trades.parquet'))

    plot_pnl_curve(pnl_intraday, os.path.join(output_dir, 'pnl_curve.png'))
    pnl_intraday.groupby('timestamp')['cumulative_pnl'].sum().to_csv(os.path.join(output_dir, 'pnl_curve.csv'))
    
    return pnl_intraday, results['trades']

def Risk_Analysis(pnl_df, ohlcv_df, output_dir):
    print("[Stage 3] Risk & Stress Analysis")
    MAX_SHARES = 1000
    DAILY_LOSS_LIMIT = 0.02
    PRICE_SHOCK = -0.05
    
    # Calculate initial capital from the first prices of each symbol
    first_prices = ohlcv_df.groupby('symbol')['close'].first()
    INITIAL_CAPITAL = (first_prices * MAX_SHARES).sum()
    MAX_LOSS_AMT = INITIAL_CAPITAL * DAILY_LOSS_LIMIT
    print(f"  Initial Capital: {INITIAL_CAPITAL:,.2f}")
    print(f"  Daily Loss Limit (2%): {MAX_LOSS_AMT:,.2f}")
    
    df = apply_position_limits(pnl_df, max_shares=MAX_SHARES)
    df['unrealized_pnl'] *= MAX_SHARES
    df['cumulative_pnl'] *= MAX_SHARES
    
    # Store PnL BEFORE risk controls for comparison
    pnl_before_risk = df.groupby('symbol')['cumulative_pnl'].last().sum()
    
    df = df.rename(columns={'unrealized_pnl': 'net_pnl'})
    df = df.join(ohlcv_df[['close']], how='left')
    df = check_daily_loss(df, initial_capital=INITIAL_CAPITAL, max_loss_pct=DAILY_LOSS_LIMIT)
    
    # Recalculate cumulative PnL after risk controls have modified net_pnl
    df['cumulative_pnl'] = df.groupby('symbol')['net_pnl'].cumsum()
    
    df = apply_price_shock(df, shock_pct=PRICE_SHOCK)
    
    # PnL AFTER risk controls
    pnl_after_risk = df.groupby('symbol')['cumulative_pnl'].last().sum()

    loss_avoided = pnl_after_risk - pnl_before_risk
    
    total_stress_pnl = df['stressed_net_pnl'].sum() 
    max_shock_drawdown = df['shock_loss'].min()
    
    print("\n" + "="*50)
    print("          RISK & STRESS TEST RESULTS")
    print("="*50)
    print(f"{'PnL Before Risk Controls':<30}: {pnl_before_risk:,.2f}")
    print(f"{'PnL After Risk Controls':<30}: {pnl_after_risk:,.2f}")
    print(f"{'PnL Impact of Stop-Loss':<30}: {loss_avoided:,.2f}")
    print("-"*50)
    print(f"{'Stressed PnL (-5% Shock)':<30}: {total_stress_pnl:,.2f}")
    print(f"{'Max Single Shock Hit':<30}: {max_shock_drawdown:,.2f}")
    print("="*50)
    
    save_to_parquet(df, os.path.join(output_dir, 'risk_results.parquet'))


def main():
    parser = argparse.ArgumentParser(description='QuantDE Backtesting Framework')
    parser.add_argument('--input', type=str, required=True, help='Input CSV path')
    parser.add_argument('--output', type=str, default='output/', help='Output directory')
    args = parser.parse_args()
    
    os.makedirs(args.output, exist_ok=True)
    
    # Run Full Pipeline
    ohlcv = Market_Data_Processing(args.input, args.output)
    pnl, trades = Strategy_Backtest(ohlcv, args.output)
    Risk_Analysis(pnl, ohlcv, args.output)
    
    print("\nPipeline execution complete. Results saved to:", args.output)

if __name__ == '__main__':
    main()
