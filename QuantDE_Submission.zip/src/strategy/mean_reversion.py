import pandas as pd

def generate_signals(df: pd.DataFrame, price_col: str = 'price') -> pd.DataFrame:
    """
    Generate mean-reversion signals based on Bollinger Bands.
    
    Rules:
    - Signal 1 (BUY): price < lower_band
    - Signal -1 (SELL): price > upper_band
    - Signal 0 (FLAT): otherwise
    
    Returns:
        DataFrame with an additional 'signal' column.
    """
    result = df.copy()
    
    result['signal'] = 0
    
    result.loc[result[price_col] < result['lower_band'], 'signal'] = 1
    result.loc[result[price_col] > result['upper_band'], 'signal'] = -1
    
    return result

