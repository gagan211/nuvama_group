import pandas as pd

def generate_intraday_pnl_curve(df_minute, trades_df, price_col='close'):
    """
    Generate minute-level cumulative PnL curve using trade-based backtest.
    """
    pnl_list = []

    for symbol in df_minute.index.get_level_values('symbol').unique():
        df_symbol = df_minute.xs(symbol, level='symbol').copy()
        df_symbol['position'] = 0
        df_symbol['unrealized_pnl'] = 0.0
        df_symbol['cumulative_pnl'] = 0.0

        trades_symbol = trades_df[trades_df['symbol'] == symbol].sort_values('entry_time')
        cum_closed_pnl = 0.0
        current_position = 0
        entry_price = 0.0

        for ts in df_symbol.index:
            trade_exit = trades_symbol[trades_symbol['exit_time'] == ts]
            if not trade_exit.empty:
                for _, trade in trade_exit.iterrows():
                    cum_closed_pnl += trade['net_pnl']
                    current_position = 0
                    entry_price = 0.0

            trade_entry = trades_symbol[trades_symbol['entry_time'] == ts]
            if not trade_entry.empty:
                for _, trade in trade_entry.iterrows():
                    current_position = 1 if trade['direction']=='LONG' else -1
                    entry_price = trade['entry_price']

            df_symbol.at[ts, 'position'] = current_position

            if current_position == 1:
                df_symbol.at[ts, 'unrealized_pnl'] = df_symbol.at[ts, price_col] - entry_price
            elif current_position == -1:
                df_symbol.at[ts, 'unrealized_pnl'] = entry_price - df_symbol.at[ts, price_col]

            df_symbol.at[ts, 'cumulative_pnl'] = cum_closed_pnl + df_symbol.at[ts, 'unrealized_pnl']

        df_symbol['symbol'] = symbol
        pnl_list.append(df_symbol[['cumulative_pnl', 'position', 'unrealized_pnl', 'symbol']])

    pnl_curve_df = pd.concat(pnl_list)
    pnl_curve_df = pnl_curve_df.set_index(['symbol'], append=True).swaplevel()
    return pnl_curve_df.sort_index()
