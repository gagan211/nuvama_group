"""
Trade-Based Backtesting Engine

Tracks actual trades (entry -> exit) with support for both LONG and SHORT positions.
PnL is calculated as:
- LONG: (Exit Price - Entry Price)
- SHORT: (Entry Price - Exit Price)
"""

import pandas as pd
import numpy as np

def run_backtest(df: pd.DataFrame, commission: float = 0.0001, price_col: str = 'close') -> dict:
    """Trade-based backtesting engine for LONG/SHORT trades."""
    all_trades = []
    
    for symbol in df.index.get_level_values('symbol').unique():
        symbol_df = df.xs(symbol, level='symbol').copy()
        
        position = 0  # 1=long, -1=short, 0=flat
        entry_price = 0.0
        entry_time = None
        
        for row in symbol_df.itertuples():
            signal = row.signal
            price = getattr(row, price_col)
            
            if position == 0:
                if signal == 1:
                    position = 1
                    entry_price = price
                    entry_time = row.Index
                elif signal == -1:
                    position = -1
                    entry_price = price
                    entry_time = row.Index
            
            elif position == 1:
                if signal == -1:
                    # Exit LONG
                    exit_price = price
                    gross_pnl = exit_price - entry_price
                    net_pnl = gross_pnl - (entry_price + exit_price) * commission
                    all_trades.append({
                        'symbol': symbol, 'direction': 'LONG',
                        'entry_time': entry_time, 'entry_price': entry_price,
                        'exit_time': row.Index, 'exit_price': exit_price,
                        'gross_pnl': round(gross_pnl, 4),
                        'commission': round((entry_price + exit_price)*commission, 4),
                        'net_pnl': round(net_pnl, 4)
                    })
                    # Enter SHORT
                    position = -1
                    entry_price = price
                    entry_time = row.Index
            
            elif position == -1:
                if signal == 1:
                    # Exit SHORT
                    exit_price = price
                    gross_pnl = entry_price - exit_price
                    net_pnl = gross_pnl - (entry_price + exit_price) * commission
                    all_trades.append({
                        'symbol': symbol, 'direction': 'SHORT',
                        'entry_time': entry_time, 'entry_price': entry_price,
                        'exit_time': row.Index, 'exit_price': exit_price,
                        'gross_pnl': round(gross_pnl, 4),
                        'commission': round((entry_price + exit_price)*commission, 4),
                        'net_pnl': round(net_pnl, 4)
                    })
                    # Enter LONG
                    position = 1
                    entry_price = price
                    entry_time = row.Index
        
        # EOD close
        if position != 0:
            last_price = symbol_df.iloc[-1][price_col]
            last_time = symbol_df.index[-1]
            if position == 1:
                gross_pnl = last_price - entry_price
                direction = 'LONG'
            else:
                gross_pnl = entry_price - last_price
                direction = 'SHORT'
            net_pnl = gross_pnl - (entry_price + last_price) * commission
            all_trades.append({
                'symbol': symbol, 'direction': direction,
                'entry_time': entry_time, 'entry_price': entry_price,
                'exit_time': last_time, 'exit_price': last_price,
                'gross_pnl': round(gross_pnl, 4),
                'commission': round((entry_price + last_price)*commission, 4),
                'net_pnl': round(net_pnl, 4),
                'eod_close': True
            })
    
    trades_df = pd.DataFrame(all_trades)
    
    if trades_df.empty:
        return {'trades': trades_df, 'total_trades':0}
    
    winning = trades_df[trades_df['net_pnl']>0]
    long_trades = trades_df[trades_df['direction']=='LONG']
    short_trades = trades_df[trades_df['direction']=='SHORT']
    
    pnl_series = trades_df['net_pnl']
    mean_pnl = pnl_series.mean()
    std_pnl = pnl_series.std()
    intra_day_sharpe = 0.0
    yearly_sharpe = 0.0
    if std_pnl > 0:
        intra_day_sharpe = (mean_pnl/std_pnl) 
        yearly_sharpe = (mean_pnl/std_pnl) * np.sqrt(len(trades_df)*252)
    
    return {
        'trades': trades_df,
        'total_trades': len(trades_df),
        'long_trades': len(long_trades),
        'short_trades': len(short_trades),
        'total_net_pnl': round(trades_df['net_pnl'].sum(),2),
        'total_commission': round(trades_df['commission'].sum(),2),
        'win_rate': round(len(winning)/len(trades_df)*100,2),
        'sharpe_ratio': round(yearly_sharpe, 3),
        'intra_day_sharpe_ratio': round(intra_day_sharpe, 3),
        'yearly_sharpe_ratio': round(yearly_sharpe, 3),
        'avg_pnl_per_trade': round(trades_df['net_pnl'].mean(),2)
    }

