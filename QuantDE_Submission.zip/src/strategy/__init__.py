# Trading strategy modules
