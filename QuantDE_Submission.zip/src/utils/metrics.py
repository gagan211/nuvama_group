"""
Performance Metrics

Calculates Win Rate, Sharpe Ratio, and PnL metrics.
"""

import pandas as pd
import numpy as np


def calculate_metrics(df: pd.DataFrame) -> dict:
    """
    Calculate performance metrics from backtest results.
    
    Required metrics:
    - Win Rate: % of trades with positive PnL
    - Sharpe Ratio: (avg return / std of return) * sqrt(periods in year)
    - Total Net PnL
    
    Args:
        df: Result DataFrame from run_backtest.
        
    Returns:
        Dictionary of metrics.
    """
    # 1. Win Rate
    # A "trade" in our bars is where net_pnl is non-zero (holding positive/negative)
    # A more common way for bar-level data is counting profitable bars when in position
    profitable_bars = df[df['net_pnl'] > 0]
    losing_bars = df[df['net_pnl'] < 0]
    
    win_rate = 0.0
    if len(profitable_bars) + len(losing_bars) > 0:
        win_rate = len(profitable_bars) / (len(profitable_bars) + len(losing_bars))
    
    # 2. Sharpe Ratio (Annualized)
    # Since we have 1-minute bars, there are ~375 bars per day, ~252 trading days/year
    # sqrt(375 * 252) ~ 307
    bars_per_year = 375 * 252 
    
    returns = df['net_pnl']
    mean_ret = returns.mean()
    std_ret = returns.std()
    
    sharpe = 0.0
    if std_ret > 0:
        sharpe = (mean_ret / std_ret) * np.sqrt(bars_per_year)
        
    # 3. Total Metrics
    total_net_pnl = df['net_pnl'].sum()
    total_commission = df['cost'].sum()
    
    return {
        'total_net_pnl': round(total_net_pnl, 2),
        'total_commission': round(total_commission, 2),
        'win_rate': round(win_rate * 100, 2),
        'sharpe_ratio': round(sharpe, 3),
        'total_trades': int(df['trade'].abs().sum() / 2) # Crude approx: count entry/exit pairs
    }
