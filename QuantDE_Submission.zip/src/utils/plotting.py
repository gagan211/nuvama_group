import matplotlib.pyplot as plt
import pandas as pd
import os

def plot_pnl_curve(pnl_df, output_path):
    """Generate portfolio-level cumulative PnL chart."""
    if 'timestamp' not in pnl_df.columns and isinstance(pnl_df.index, pd.MultiIndex):
        pnl_df = pnl_df.reset_index()
    
    portfolio_pnl = pnl_df.groupby('timestamp')['cumulative_pnl'].sum()
    
    plt.figure(figsize=(12, 6))
    plt.plot(portfolio_pnl.index, portfolio_pnl.values, label='Portfolio PnL', color='green')
    plt.title('Strategy Performance - Cumulative PnL')
    plt.xlabel('Time')
    plt.ylabel('PnL')
    plt.grid(True, alpha=0.3)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def plot_bollinger_bands(df, output_dir):
    """Generate Bollinger Band charts for each symbol."""
    os.makedirs(output_dir, exist_ok=True)
    if isinstance(df.index, pd.MultiIndex):
        df = df.reset_index()
        
    for symbol in df['symbol'].unique():
        symbol_df = df[df['symbol'] == symbol].sort_values('timestamp')
        plt.figure(figsize=(12, 6))
        plt.plot(symbol_df['timestamp'], symbol_df['close'], label='Close', color='blue', alpha=0.6)
        plt.plot(symbol_df['timestamp'], symbol_df['sma_20'], label='SMA 20', color='orange', linestyle='--')
        plt.fill_between(symbol_df['timestamp'], symbol_df['lower_band'], symbol_df['upper_band'], color='gray', alpha=0.2)
        plt.title(f'Bollinger Bands - {symbol}')
        plt.legend()
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'{symbol}_bb.png'))
        plt.close()
