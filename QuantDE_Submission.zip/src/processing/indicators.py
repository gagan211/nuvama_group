"""
Technical Indicators

Computes rolling SMA and volatility for OHLCV data.
"""

import pandas as pd

def add_moving_average(df: pd.DataFrame, period: int = 20, column: str = 'close') -> pd.DataFrame:
    """Add Simple Moving Average (SMA) to the DataFrame."""
    result = df.copy()
    result[f'sma_{period}'] = result.groupby(level='symbol')[column].transform(
        lambda x: x.rolling(window=period, min_periods=period).mean()
    )
    return result


def add_volatility(df: pd.DataFrame, period: int = 20, column: str = 'close') -> pd.DataFrame:
    """Add rolling volatility (standard deviation) to the DataFrame."""
    result = df.copy()
    result[f'volatility_{period}'] = result.groupby(level='symbol')[column].transform(
        lambda x: x.rolling(window=period, min_periods=period).std()
    )
    return result


def add_bollinger_bands(df: pd.DataFrame, period: int = 20, num_std: float = 1.0) -> pd.DataFrame:
    """Add Bollinger Bands (SMA +/- n*std) for mean-reversion signals."""
    sma_col = f'sma_{period}'
    vol_col = f'volatility_{period}'
    
    if sma_col not in df.columns:
        df = add_moving_average(df, period)
    if vol_col not in df.columns:
        df = add_volatility(df, period)
    
    result = df.copy()
    result['upper_band'] = result[sma_col] + (num_std * result[vol_col])
    result['lower_band'] = result[sma_col] - (num_std * result[vol_col])
    return result
