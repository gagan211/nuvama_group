import pandas as pd

def resample_ohlcv(ticks: pd.DataFrame, freq: str = '1min') -> pd.DataFrame:
    """    
    For each time window:
    - Open: First price in the window
    - High: Maximum price in the window
    - Low: Minimum price in the window
    - Close: Last price in the window (e.g., :59 second for 1-min bars)
    - Volume: Sum of all tick volumes in the window
    
    Returns:
        Sampled DataFrame with the freq param
    """
    ohlcv_list = []
    
    for symbol in ticks['symbol'].unique():
        symbol_ticks = ticks[ticks['symbol'] == symbol]
        
        ohlc = symbol_ticks['price'].resample(freq).agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last'
        })
        
        volume = symbol_ticks['volume'].resample(freq).sum()
        bars = pd.concat([ohlc, volume.rename('volume')], axis=1)
        bars['symbol'] = symbol
        
        ohlcv_list.append(bars)
    
    result = pd.concat(ohlcv_list)
    result = result.reset_index()
    result = result.set_index(['timestamp', 'symbol'])
    result = result.sort_index()
    
    result = result.dropna()
    
    return result
