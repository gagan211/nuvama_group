import pandas as pd


def apply_price_shock(df: pd.DataFrame, shock_pct: float = -0.05) -> pd.DataFrame:
    """
    Apply a price shock and recalculate PnL.
    README: shock all prices by -5% in a single day.
    
    Logic:
    We simulate this by reducing the 'close' price of all symbols 
    and seeing how it impacts the existing strategy's PnL.
    
    Args:
        df: DataFrame with 'close', 'position', 'net_pnl'.
        shock_pct: Price change as decimal (-0.05 for -5%).
        
    Returns:
        DataFrame with stressed PnL.
    """
    result = df.copy()
    result['stressed_close'] = result['close'] * (1 + shock_pct)
    result['shock_loss'] = result['adj_position'] * (result['close'] * shock_pct)
    
    # This is a one-time total portfolio hit
    result['shock_loss'] = result['adj_position'] * (result['close'] * shock_pct)
    
    # Stressed PnL = Original PnL + Shock Loss 
    result['stressed_net_pnl'] = result['net_pnl'] + result['shock_loss']
    
    return result
