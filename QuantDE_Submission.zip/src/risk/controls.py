"""
Risk Management Controls

Implements position limits and daily loss constraints.
"""

import pandas as pd
import numpy as np


def apply_position_limits(df: pd.DataFrame, max_shares: int = 1000) -> pd.DataFrame:
    """
    Limit the number of shares held per symbol.
    """
    result = df.copy()
    result['adj_position'] = result['position'] * max_shares
    return result


def check_daily_loss(df: pd.DataFrame, initial_capital: float, max_loss_pct: float = 0.02) -> pd.DataFrame:
    """
    Enforce a maximum daily loss limit (Stop-loss for the day).
    If cumulative PnL drops below 2% of starting capital, positions are flattened.
    """
    result = df.copy()
    max_loss_amt = initial_capital * max_loss_pct
    
    # Calculate running cumulative PnL across all symbols
    result['daily_cum_pnl'] = result['net_pnl'].cumsum()
    
    violation = result['daily_cum_pnl'] < -max_loss_amt
    
    if violation.any():
        first_violation_idx = result[violation].index[0]
        pnl_at_breach = result.loc[first_violation_idx, 'daily_cum_pnl']
        print(f"Daily loss limit exceeded at {first_violation_idx}. PnL at breach: {pnl_at_breach:,.2f}")
        
        mask = result.index >= first_violation_idx
        result.loc[mask, 'adj_position'] = 0
        result.loc[mask, 'net_pnl'] = 0
    else:
        print("Daily loss limit NOT exceeded.")
        
    return result
