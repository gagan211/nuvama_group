# QuantDE Backtesting Framework

A modular Python framework for market data processing, mean-reversion strategy backtesting, and risk analysis.

## Setup
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Quick Start
Run the unified pipeline using either method:
```bash
# Option 1: Using start script
./start.sh

# Option 2: Direct Python call
python3 src/main.py --input sample_tick_data.csv
```


## Output Files
| File | Description |
|------|-------------|
| `output/ohlcv_ready.parquet` | 1-min OHLCV with SMA & Bollinger Bands |
| `output/trades.parquet` | Trade log (entry/exit, PnL, direction) |
| `output/intraday_pnl.parquet` | Minute-level cumulative PnL |
| `output/pnl_curve.png` | Portfolio PnL graph |
| `output/pnl_curve.csv` | PnL curve data |
| `output/plots/` | Bollinger Band charts per symbol |
| `output/risk_results.parquet` | Risk-adjusted results |

## Project Structure
```
src/
|-- data/loader.py          # CSV/Parquet I/O
|-- processing/
|   |-- resampler.py        # Tick -> 1-min OHLCV
|   |-- indicators.py       # SMA, volatility, Bollinger Bands
|-- strategy/
|   |-- mean_reversion.py   # Signal generation
|   |-- backtest.py         # Trade-based backtest engine
|   |-- pnl.py              # Minute-level PnL tracking
|-- risk/
|   |-- controls.py         # Position limits, daily loss stop
|   |-- stress_test.py      # -5% price shock simulation
|-- utils/
|   |-- plotting.py         # Visualization utilities
|-- main.py                 # Unified CLI entry point
```

## Requirements
- Python 3.10+
- pandas, numpy, pyarrow, matplotlib
