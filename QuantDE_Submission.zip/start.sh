#!/bin/bash
# QuantDE Backtesting Framework - Start Script

echo "=================================="
echo "  QuantDE Backtesting Framework"
echo "=================================="

# Check if input file exists
INPUT_FILE="${1:-sample_tick_data.csv}"

if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: Input file '$INPUT_FILE' not found."
    echo "Usage: ./start.sh [input_csv_path]"
    exit 1
fi

# Create output directory
mkdir -p output

# Run the unified pipeline
echo "Running backtest pipeline with input: $INPUT_FILE"
python3 src/main.py --input "$INPUT_FILE"

echo ""
echo "Backtest complete. Check the 'output/' directory for results."
