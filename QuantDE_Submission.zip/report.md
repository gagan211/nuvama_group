# QuantDE Take-Home Test - Technical Report

## 1. System Architecture

Modular Python package with clear separation of concerns:

```
+----------------+     +------------------+     +----------------+
|   Data Layer   | --> | Processing Layer | --> | Strategy Layer |
| (loader.py)    |     | (resampler.py,   |     | (mean_reversion|
|                |     |  indicators.py)  |     |  backtest.py)  |
+----------------+     +------------------+     +----------------+
                                                       |
                                                       v
                                               +----------------+
                                               |   Risk Layer   |
                                               | (controls.py,  |
                                               |  stress_test)  |
                                               +----------------+
```

- **Data Layer**: Handles CSV tick data ingestion and Parquet I/O for fast columnar storage.
- **Processing Layer**: Resamples ticks to 1-minute OHLCV bars; computes 20-period SMA and Bollinger Bands.
- **Strategy Layer**: Generates mean-reversion signals; executes trade-based backtest with LONG/SHORT support.
- **Risk Layer**: Applies position limits (1,000 shares), daily stop-loss (2%), and stress testing (-5% shock).

---

## 2. Strategy Implementation

| Component | Implementation |
|-----------|----------------|
| Indicator | 20-period SMA with 1-std Bollinger Bands |
| Entry | Long: close < lower_band, Short: close > upper_band |
| Exit | Opposite signal or EOD forced close |
| Commission | 0.01% per trade (entry + exit) |

---

## 3. Performance Results

| Metric | Value |
|--------|-------|
| Total Trades | 51 |
| Long / Short | 25 / 26 |
| Win Rate | 64.71% |
| Net PnL (per share) | -33.73 |
| Net PnL (1000 shares) | -33,733.30 |
| Sharpe Ratio (Yearly) | -3.79 |

---

## 4. Risk Implementation

### Position Limits
- Max 1,000 shares per symbol at any time.
- Implemented in `controls.py:apply_position_limits()`.

### Daily Stop-Loss
- If cumulative loss exceeds 2% of initial capital, all positions are flattened.
- Initial capital is dynamically calculated from first prices of each symbol.
- Example: 3 symbols at ~$1000 each x 1000 shares = ~$3M capital, 2% limit = ~$60K.

### Stress Test
- Simulates a -5% instantaneous price shock across all holdings.
- Calculates `shock_loss = position * price * (-0.05)`.
- Reports stressed PnL and maximum single-bar shock impact.

---

## 5. AI Usage Documentation

| Aspect     | Details |
|------------|---------|
| Tool       | Antigravity |
| Prompts    | Architecture design, vectorized backtest, testing on different data frequencies |
| Accepted   | SMA over EMA (better Sharpe), minute-level data over tick-level |
| Rejected   | Initial tick-level approach (too granular for 20-period lookback), EMA over SMA, `iterrows()` calls (slower than `itertuples()`), random allocation of margin [1,000,000] , position based pnl computations [inaccurate] |

---

## 6. Production Scaling (Databricks/AWS)

| Component | Current | Production Scale |
|-----------|---------|------------------|
| Data Processing | Pandas DataFrame | PySpark on Databricks |
| Storage | Local Parquet | Delta Lake on S3 |
| Streaming | Batch CSV | Kafka/Kinesis for real-time ticks |
| Orchestration | CLI script | Airflow/Databricks Workflows |
| Monitoring | Print statements | MLflow + CloudWatch |

### Key Changes for Scale:
1. Replace `pd.DataFrame` with `spark.sql.DataFrame` for distributed processing.
2. Use Delta Lake for ACID transactions, schema evolution, and time-travel.
3. Deploy backtest as a Databricks job with parameterized runs.
4. Add historical data partitioning by date for efficient queries.
